package com.cydeo.enums;

public enum AddressType {

    STUDENT, TEACHER, PARENT

}
