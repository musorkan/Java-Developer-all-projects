package com.cydeo.enums;

public enum Status {

    ACTIVE, FINISHED, PENDING, MOVED

}
