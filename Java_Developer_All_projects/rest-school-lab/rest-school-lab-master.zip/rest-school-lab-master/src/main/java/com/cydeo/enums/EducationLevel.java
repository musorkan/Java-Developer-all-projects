package com.cydeo.enums;

public enum EducationLevel {

    BACHELOR, MASTER, DOCTORAL

}
