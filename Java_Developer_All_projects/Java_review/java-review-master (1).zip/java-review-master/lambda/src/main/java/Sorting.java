
@FunctionalInterface
public interface Sorting {
    public void sort();

}
