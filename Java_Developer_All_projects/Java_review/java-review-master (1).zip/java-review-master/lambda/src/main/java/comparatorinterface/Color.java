package comparatorinterface;

public enum Color {
    RED,GREEN;
}
