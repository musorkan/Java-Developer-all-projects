package task;

public interface OrangeFormatter {
    String accept(Orange orange);
}
