package doublecolonoperator;

public interface Calculate {
    void calculate(int x,int y);
}
