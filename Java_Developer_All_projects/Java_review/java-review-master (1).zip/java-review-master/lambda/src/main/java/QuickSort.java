public class QuickSort implements Sorting {
    @Override
    public void sort() {
        System.out.println("Quicksorting");
    }
}
