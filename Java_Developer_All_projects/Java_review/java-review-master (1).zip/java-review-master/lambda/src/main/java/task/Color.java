package task;

public enum Color {
    RED,GREEN;
}
