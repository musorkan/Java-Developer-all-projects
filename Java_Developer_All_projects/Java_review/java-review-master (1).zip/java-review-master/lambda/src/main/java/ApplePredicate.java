public interface ApplePredicate {
    boolean test(Apple apple);
}
