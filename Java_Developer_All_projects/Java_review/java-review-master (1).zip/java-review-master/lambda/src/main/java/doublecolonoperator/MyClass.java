package doublecolonoperator;

public class MyClass {
    public double method(Integer x){
        return x*2.5;
    }
}
