package doublecolonoperator;

public class Calculator {

    public static void findSum(int x,int y){
        System.out.println("Sum " + (x+y));
    }

    public void findMultiply(int x,int y){
        System.out.println("Multiply " + (x*y));
    }
}
