package com.cydeo.oopreview.exception;

public class InvalidPaymentStrategyException extends Exception {
    public InvalidPaymentStrategyException(String message) {
        super(message);
    }
}
