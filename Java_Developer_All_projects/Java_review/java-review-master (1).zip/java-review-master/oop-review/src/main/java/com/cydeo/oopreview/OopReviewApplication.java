package com.cydeo.oopreview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OopReviewApplication {

    public static void main(String[] args) {

        SpringApplication.run(OopReviewApplication.class, args);


    }

}
