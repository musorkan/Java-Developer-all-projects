package com.cydeo.oopreview.enums;

public enum PaymentStrategy {
    TENANT,
    HYBRID
}
