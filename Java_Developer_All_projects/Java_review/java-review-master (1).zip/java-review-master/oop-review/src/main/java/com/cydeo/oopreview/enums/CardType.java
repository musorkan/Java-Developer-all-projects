package com.cydeo.oopreview.enums;

public enum CardType {
    DEBIT,
    CREDIT_CARD
}
