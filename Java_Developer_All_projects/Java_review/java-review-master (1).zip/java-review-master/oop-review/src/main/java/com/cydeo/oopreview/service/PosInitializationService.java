package com.cydeo.oopreview.service;

import com.cydeo.oopreview.model.pos.Pos;

import java.util.List;

public interface PosInitializationService {
    List<Pos> initializePosList();
}
