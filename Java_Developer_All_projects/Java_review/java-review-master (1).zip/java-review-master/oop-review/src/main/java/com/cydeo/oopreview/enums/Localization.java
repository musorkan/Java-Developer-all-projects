package com.cydeo.oopreview.enums;

public enum Localization {
    ENG,
    FR,
    IT,
    TR,
    DE
}
