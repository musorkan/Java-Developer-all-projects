package com.cydeo.oopreview.enums;

public enum ServiceProvider {
    AMEX,
    VISA,
    MASTER_CARD
}
