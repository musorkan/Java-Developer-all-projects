public enum Type {
    MEAT,FISH,OTHER;
}
