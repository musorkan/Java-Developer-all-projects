package com.cydeo.banksimulation.exception;

public class AccountStatusInvalidException extends RuntimeException {

    public AccountStatusInvalidException(String s) {
        super(s);
    }

}
