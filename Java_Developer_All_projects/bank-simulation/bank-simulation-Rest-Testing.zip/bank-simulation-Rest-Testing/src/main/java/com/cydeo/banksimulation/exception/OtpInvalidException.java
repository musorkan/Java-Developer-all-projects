package com.cydeo.banksimulation.exception;

public class OtpInvalidException extends RuntimeException {

    public OtpInvalidException(String s) {
        super(s);
    }

}
