package com.cydeo.banksimulation.enums;

public enum AccountType {
    CHECKINGS, SAVINGS
}
