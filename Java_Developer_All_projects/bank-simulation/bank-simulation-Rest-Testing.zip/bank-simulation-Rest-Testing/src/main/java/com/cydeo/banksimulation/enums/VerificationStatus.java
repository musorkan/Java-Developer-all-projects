package com.cydeo.banksimulation.enums;

public enum VerificationStatus {
    PENDING, APPROVED
}
