package com.cydeo.banksimulation.exception;

public class BalanceNotSufficientException extends RuntimeException {

    public BalanceNotSufficientException(String s) {
        super(s);
    }

}
