package com.cydeo.banksimulation.exception;

public class SmsException extends RuntimeException {

    public SmsException(String s) {
        super(s);
    }

}
