insert into accounts (id, account_status, account_type, balance, creation_date, otp_verified,
                      phone_number, user_id)
values (1,'ACTIVE', 'CHECKINGS', 123, '2022-03-19', true, '13214123', 123);

insert into accounts (id, account_status, account_type, balance, creation_date, otp_verified, phone_number, user_id)
values (2,'DELETED', 'CHECKINGS', 250, '2022-03-19', true, '132141232', 23);


insert into accounts (id, account_status, account_type, balance, creation_date, otp_verified, phone_number, user_id)
values (3,'ACTIVE', 'SAVINGS', 133, '2022-03-19', true, '132141233', 13);


insert into accounts (id, account_status, account_type, balance, creation_date, otp_verified, phone_number, user_id)
values (4,'ACTIVE', 'CHECKINGS', 133, '2022-03-19', true, '132141233', 13);

