package com.cydeo.banksimulation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankSimulationApplicationTests {

    @Test
    void contextLoads() {
    }

}
