package com.cydeo.banksimulation.enums;

public enum AccountStatus {
    ACTIVE,
    DELETED
}
