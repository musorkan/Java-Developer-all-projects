package com.cydeo.banksimulation.exception;

public class UnderConstructionException extends RuntimeException {
    public UnderConstructionException(String s) {

        super(s);
    }
}
