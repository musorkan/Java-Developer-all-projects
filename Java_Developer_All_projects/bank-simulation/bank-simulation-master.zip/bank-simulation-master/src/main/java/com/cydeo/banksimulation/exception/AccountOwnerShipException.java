package com.cydeo.banksimulation.exception;

public class AccountOwnerShipException extends RuntimeException {
    public AccountOwnerShipException(String message) {
        super(message);
    }
}
