package com.cydeo.exception;

public class TicketingProjectException extends Exception {

    public TicketingProjectException(String message){
        super(message);
    }
}
