package math;

public interface AnimalPredicate {
    boolean test(Animal animal);
}
