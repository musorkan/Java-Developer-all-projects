import java.util.Locale;

public class AnimalFeast {

    public static void main(String[] args) {
        System.out.println(dishAnimal("great blue heron", "garlic naan"));
        System.out.println(dishAnimal("chickadee", "chocolate cake"));
    }


    public static boolean dishAnimal(String animal, String dish) {
        return animal.charAt(0) == dish.charAt(0) && animal.charAt(animal.length() - 1) == dish.charAt(dish.length() - 1);
    }

    //solution of jose
    public static boolean feast(String animal,String dish){

        return dish.startsWith(animal.substring(0,1)) && dish.endsWith(animal.substring(animal.length()-1,animal.length()));

    }

    //solution of andrei
    public static boolean animalAccess(String animal, String dish) {
        animal = animal.trim().toLowerCase(Locale.ROOT);
        dish = dish.trim().toLowerCase(Locale.ROOT);
        animal = (animal.startsWith("-")) ? animal.replaceFirst("-", "") : animal;
        dish = (dish.startsWith("-")) ? dish.replaceFirst("-", "") : dish;
        animal = (animal.endsWith("-")) ? animal.substring(0, animal.length() - 1) : animal;
        dish = (dish.endsWith("-")) ? dish.substring(0, dish.length() - 1) : dish;
        if (animal.matches(".*\\d.*") || dish.matches(".*\\d.*")) return false;
        if (animal.length() < 2 || dish.length() < 2) return false;
        else
            return animal.charAt(0) == dish.charAt(0) && animal.charAt(animal.length() - 1) == dish.charAt(dish.length() - 1);
    }

    //solution of vitaly
    public static boolean animalFeast(String dish, String animal) {
        char[] dishArr = dish.toCharArray();
        char[] animalArr = animal.toCharArray();
        if (dishArr[0] == animalArr[0]
                && dishArr[dishArr.length - 1] == animalArr[animalArr.length - 1]) return true;
        return false;
    }



}
