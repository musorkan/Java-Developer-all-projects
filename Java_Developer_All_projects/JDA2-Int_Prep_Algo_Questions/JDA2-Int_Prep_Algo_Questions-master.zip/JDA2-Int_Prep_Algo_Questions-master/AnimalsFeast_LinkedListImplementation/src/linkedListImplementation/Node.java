package linkedListImplementation;

public class Node {

    Node next;
    Integer value;

    public Node(Integer value) {
        this.value = value;
    }


}
