# JDA2-Int_Prep_Algo_Questions
Algoritm Questions for JD-A2,

Clone this repo to your IntelliJ, please make sure to set SDK for your Project.....

Go to File -> Project Structure -> Project -> SDK and Language Level (SET same level for both)

