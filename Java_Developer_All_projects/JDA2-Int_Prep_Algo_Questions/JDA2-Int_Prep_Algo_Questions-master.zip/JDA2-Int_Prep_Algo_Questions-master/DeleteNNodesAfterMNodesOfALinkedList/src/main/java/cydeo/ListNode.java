package cydeo;

public class ListNode {

    public ListNode next;
    public int value;

    public ListNode(int value) {
        this.value = value;
    }
}


