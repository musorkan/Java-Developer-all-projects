import java.util.HashSet;
import java.util.Set;

public class GenerateDocument_Solution2 {
    public static void main(String[] args) {
        String characters= "veDJaCyd vaeo perelo xw!";
        String document="Cydeo Java Developer!";

        System.out.println((generateDocumentSolution2(characters, document)));
    }
    // O(c * (n + m)) time | O(c) space - where n is the number of characters,
    // the length of the document, and c is the number of unique characters in
    // document
    public static boolean generateDocumentSolution2(String characters, String document) {
        Set<Character> alreadyCounted = new HashSet<Character>();
        for (int idx = 0; idx < document.length(); idx++) {
            char character = document.charAt(idx);
            if (alreadyCounted.contains(character)) {
                continue;
            }
            int documentFrequency = countCharacterFrequency(character, document);
            int charactersFrequency = countCharacterFrequency(character, characters);
            if (documentFrequency > charactersFrequency) {
                return false;
            }
            alreadyCounted.add(character);
        }
        return true;
    }
    public static int countCharacterFrequency(char character, String target) {
        int frequency = 0;
        for (int idx = 0; idx < target.length(); idx++) {
            char c = target.charAt(idx);
            if (c == character) {
                frequency += 1;
            }
        }
        return frequency;
    }


}
