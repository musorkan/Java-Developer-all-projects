public class GenerateDocument_BruteForceSolution {
    public static void main(String[] args) {
        String characters= "veDJaCyd vaeo perelo xw!";
        String document="Cydeo Java Developer!";

        System.out.println((generateDocumentBruteForce(characters, document)));
    }
        public static boolean generateDocumentBruteForce(String ch, String doc) {
            for (int idx = 0; idx < doc.length(); idx++) {
                char character = doc.charAt(idx);
                int documentFrequency = countCharacterFrequency(character, doc);
                int charactersFrequency = countCharacterFrequency(character, ch);
                if (documentFrequency > charactersFrequency) {
                    return false;
                }
            }
            return true;
        }
        public static int countCharacterFrequency(char character, String target) {
            int frequency = 0;
            for (int idx = 0; idx < target.length(); idx++) {
                char c = target.charAt(idx);
                if (c == character) {
                    frequency += 1;
                }
            }
            return frequency;
        }


}
