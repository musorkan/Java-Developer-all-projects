INSERT INTO student(first_name, last_name, age)
VALUES ('Mike', 'Smith', 20);
