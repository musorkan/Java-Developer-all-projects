package com.cydeo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring23IntegrationTestingMockMvcApplication {

    public static void main(String[] args) {
        SpringApplication.run(Spring23IntegrationTestingMockMvcApplication.class, args);
    }

}
