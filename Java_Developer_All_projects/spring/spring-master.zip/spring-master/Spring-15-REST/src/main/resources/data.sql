INSERT INTO COURSES(NAME, CATEGORY, RATING, DESCRIPTION)
    VALUES('Rapid Spring Boot Application Development', 'Spring', 4,
'Spring Boot gives all the power of the Spring Framework without all of the complexities');
INSERT INTO COURSES(NAME, CATEGORY, RATING, DESCRIPTION)
    VALUES('Getting Started with Spring Security DSL','Spring', 3,  'Learn Spring Security DSL in easy steps');
INSERT INTO COURSES(NAME, CATEGORY, RATING, DESCRIPTION)
    VALUES('Scalable, Cloud Native Data Applications', 'Spring', 4,  'Manage Cloud based applications with Spring Boot');
INSERT INTO COURSES(NAME, CATEGORY, RATING, DESCRIPTION)
    VALUES('Fully Reactive: Spring, Kotlin, and JavaFX Playing Together', 'Spring', 3,
'Unleash the power of Reactive Spring with Kotlin and Spring Boot');
INSERT INTO COURSES(NAME, CATEGORY, RATING, DESCRIPTION)
    VALUES('Getting Started with Spring Cloud Kubernetes', 'Spring', 5, 'Master Spring Boot application deployment with Kubernetes');
