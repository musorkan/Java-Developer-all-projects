package com.cydeo.enums;

public enum UserRole {
    ADMIN, USER
}
