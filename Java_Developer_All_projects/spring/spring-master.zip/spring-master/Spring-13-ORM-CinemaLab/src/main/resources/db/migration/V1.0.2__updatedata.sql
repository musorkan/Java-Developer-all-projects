INSERT INTO location (name, address, postal_code, country, state, city) VALUES
                                                                            ('AMC Empire 25', '234 W 42nd St', '10036', 'United States', 'New York', 'New York'),
                                                                            ('AMC 34th Street 14', '312 W 34th St', '10001', 'United States', 'New York', 'New York'),
                                                                            ('AMC Lincoln Square 13', '1998 Broadway', '10023', 'United States', 'New York', 'New York'),
                                                                            ('AMC Village 7', '66 3rd Ave', '10003', 'United States', 'New York', 'New York');