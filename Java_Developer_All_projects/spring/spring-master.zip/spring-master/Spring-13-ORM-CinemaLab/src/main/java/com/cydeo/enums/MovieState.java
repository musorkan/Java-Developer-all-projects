package com.cydeo.enums;

public enum MovieState {
    ACTIVE,DRAFT,SUSPENDED;
}
