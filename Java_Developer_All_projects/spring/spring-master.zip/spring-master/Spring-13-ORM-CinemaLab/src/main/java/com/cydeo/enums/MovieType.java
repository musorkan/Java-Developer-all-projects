package com.cydeo.enums;

public enum MovieType {
    PREMIER,REGULAR;
}
