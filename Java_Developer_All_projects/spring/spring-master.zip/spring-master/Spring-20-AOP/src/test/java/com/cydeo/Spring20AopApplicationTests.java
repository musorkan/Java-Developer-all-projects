package com.cydeo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring20AopApplicationTests {

    @Test
    void contextLoads() {
    }

}
