package com.cydeo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring24DockerApplication {

    public static void main(String[] args) {
        SpringApplication.run(Spring24DockerApplication.class, args);
    }

}
