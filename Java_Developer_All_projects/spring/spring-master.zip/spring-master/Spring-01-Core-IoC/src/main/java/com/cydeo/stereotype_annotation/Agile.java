package com.cydeo.stereotype_annotation;

import org.springframework.stereotype.Component;

@Component
public class Agile {
    public void getTeachingHours(){
        System.out.println("Total teaching hours : 15");
    }
}
