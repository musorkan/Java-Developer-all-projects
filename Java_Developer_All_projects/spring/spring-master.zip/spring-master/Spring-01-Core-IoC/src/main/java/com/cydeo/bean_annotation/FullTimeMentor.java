package com.cydeo.bean_annotation;

public class FullTimeMentor {

    public void createAccount(){
        System.out.println("Full Time Mentor is created");
    }
}
