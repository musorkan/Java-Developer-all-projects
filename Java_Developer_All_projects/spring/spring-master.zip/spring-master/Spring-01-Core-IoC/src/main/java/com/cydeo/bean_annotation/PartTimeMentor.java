package com.cydeo.bean_annotation;

public class PartTimeMentor {

    public void createAccount(){
        System.out.println("Part Time Mentor is created");
    }
}
