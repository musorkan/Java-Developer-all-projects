package com.cydeo.stereotype_annotation;

import org.springframework.stereotype.Component;


public class Selenium {
    public void getTeachingHours(){
        System.out.println("Total teaching hours : 200");
    }
}
