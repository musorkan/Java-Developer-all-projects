
-- INSERT INTO EMPLOYEES(id,name)
-- VALUES(1,'Mike Smith');


INSERT INTO student(first_name,last_name,email)
VALUES('Mike',' Smith','mike@cydeo.com');


