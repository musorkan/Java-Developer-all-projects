package com.cydeo.loosely_coupled;

public class FullTimeMentor implements Mentor{
    public void createAccount() {
        System.out.println("Full Time Mentor Account is created...");
    }
}
