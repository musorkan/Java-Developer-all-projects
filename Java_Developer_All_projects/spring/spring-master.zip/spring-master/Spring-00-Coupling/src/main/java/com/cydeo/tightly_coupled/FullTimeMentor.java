package com.cydeo.tightly_coupled;

public class FullTimeMentor {
    public void createAccount(){
        System.out.println("Full Time Mentor Account is created.");
    }
}
