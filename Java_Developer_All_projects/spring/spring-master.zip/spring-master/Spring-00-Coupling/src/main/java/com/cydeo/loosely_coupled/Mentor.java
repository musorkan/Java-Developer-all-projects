package com.cydeo.loosely_coupled;

public interface Mentor {
    void createAccount();
}
