package com.cydeo.loosely_coupled;

public class PartTimeMentor implements Mentor {
    public void createAccount() {

        System.out.println("Part Time Mentor Account is created...");
    }
}
