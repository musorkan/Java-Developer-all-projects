package com.cydeo.enums;

public enum Gender {
    MALE,FEMALE;
}
