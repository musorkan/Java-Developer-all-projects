package com.cydeo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring08SpringMvcModelApplicationTests {

    @Test
    void contextLoads() {
    }

}
