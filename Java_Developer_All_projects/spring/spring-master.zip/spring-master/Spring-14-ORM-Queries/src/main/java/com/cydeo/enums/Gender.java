package com.cydeo.enums;

public enum Gender {
    M,F
}
