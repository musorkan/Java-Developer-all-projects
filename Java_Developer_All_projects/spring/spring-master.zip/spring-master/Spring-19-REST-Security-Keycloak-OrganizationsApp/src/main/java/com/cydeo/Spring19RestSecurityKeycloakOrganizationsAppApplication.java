package com.cydeo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring19RestSecurityKeycloakOrganizationsAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(Spring19RestSecurityKeycloakOrganizationsAppApplication.class, args);
    }

}
