package com.cydeo.enums;

public enum Status {

    SUCCESS,FAILURE;
}
