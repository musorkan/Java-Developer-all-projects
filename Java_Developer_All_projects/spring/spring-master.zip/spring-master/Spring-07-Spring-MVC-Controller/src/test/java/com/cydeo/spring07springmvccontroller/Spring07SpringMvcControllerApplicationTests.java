package com.cydeo.spring07springmvccontroller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring07SpringMvcControllerApplicationTests {

    @Test
    void contextLoads() {
    }

}
