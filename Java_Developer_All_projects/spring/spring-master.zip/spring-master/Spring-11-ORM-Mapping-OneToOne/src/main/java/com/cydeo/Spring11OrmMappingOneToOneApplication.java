package com.cydeo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring11OrmMappingOneToOneApplication {

    public static void main(String[] args) {
        SpringApplication.run(Spring11OrmMappingOneToOneApplication.class, args);
    }

}
