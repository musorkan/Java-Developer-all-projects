public class MyNode {
    String name;
    MyNode next;// default value will be null
    public MyNode(String name) {
        this.name = name;
    }
}
