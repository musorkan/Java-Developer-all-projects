public class Node {
    Node leftChild;
    Node rightChild;
    int value;

    public Node() {
    }
    public Node(int value) {
        this.value = value;
    }
}
